clc;clear;
% Clear the workspace and the screen
sca;
close all;
clearvars;
%%
%input
prompt={'���','part'};
subjdata.subinfo=inputdlg(prompt);
if isempty(subjdata.subinfo{1})==1
    error('������ʾ');
else   
end
%%
%folder with pic
cFolder=pwd;
% Here we call some default settings for setting up Psychtoolbox
PsychDefaultSetup(2);
% Get the screen numbers
screens = Screen('Screens');
% Draw to the external screen if avaliable
screenNumber = max(screens);
% Define black and white
black = BlackIndex(screenNumber);
% Open an on screen window
[window, windowRect] = PsychImaging('OpenWindow', screenNumber, 0.8);  %0.8=gray
%%invest parameter
% Get the size of the on screen window
[screenXpixels, screenYpixels] = Screen('WindowSize', window);

% Query the frame duration
ifi = Screen('GetFlipInterval', window);

% The avaliable keys to press
escapeKey = KbName('ESCAPE');
leftKey = KbName('1!');
rightKey = KbName('2@');
comfrimKey=KbName('4$');
comfrimKey2=KbName('s');

% Get the centre coordinate of the window
[xCenter, yCenter] = RectCenter(windowRect);

% Set the intial position of the square to be in the centre of the screen
squareX = xCenter;
squareX1 = xCenter;
squareY = yCenter;
%defined the choice of invest
aax=windowRect(3:4);
aaxx=round(aax(1)/18.5);
aaxx1=aaxx/2;
xyx=[xCenter-aaxx1,xCenter+aaxx1];
xyy=[yCenter-aaxx1,yCenter+aaxx1];
xyx1=xyx-1.5*aaxx;
xyx2=xyx+1.5*aaxx;
for o=1:4
    xyx1(o+1,:)=xyx1(o,:)-1.5*aaxx;
    xyx2(o+1,:)=xyx2(o,:)+1.5*aaxx;
end
% Set the amount we want our square to move on each button press
pixelsPerPress = 1.5*aaxx;

% Make a base Rect of 200 by 200 pixels
baseRect = [0 0 aaxx aaxx];
%%predict parameter
%defined the choice of invest
aax1=windowRect(3:4);
aaxx2=round(aax1(1)/4);

xyxp=[aaxx2+aaxx2/2,aaxx2*3-aaxx2/2];
xyyp=[yCenter*2/3,yCenter*2/3*2];
wid=yCenter/4;
% Set the amount we want our square to move on each button press
pixelsPerPress1 = 1;
% Make a base Rect of 200 by 200 pixels
baseRectp = [0 0 aaxx2 aaxx2];


%subj info
% response parameter
% xprobilty1=[33,33,33;28	33	38;28	28	43;23	28	48;23	23	53;18	23	58;18	18	63;...
%     13	18	68;13	13	73;8	13	78;8	8	83;3	8	88;3	3	93];
xprobilty1=[33,33,33;28	28	43;23	23	53;18	18	63;...
    13	13	73;8	8	83;3	3	93];
% xprobilty1=[33,33,33;33,33,33;33,33,33;33,33,33;33,33,33;33,33,33;33,33,33;];
i1=1;
% xprobilty2=[33,33,33;28	33	38;28	28	43;23	28	48;23	23	53;18	23	58;18	18	63;...
%     13	18	68;13	13	73;8	13	78;8	8	83;3	8	88;3	3	93]
xprobilty2=[33,33,33;28	28	43;23	23	53;18	18	63;...
    13	13	73;8	8	83;3	3	93];
% xprobilty2=[33,33,33;33,33,33;33,33,33;33,33,33;33,33,33;33,33,33;33,33,33;];
i2=1
load('trialorder.mat');
load('timeorder.mat');
loop_pra=1

trial_s=trial_s1(1:10);



%allow chinese
Screen('TextFont',window,'-:lang=zh-cn');
%%
% Set up alpha-blending for smooth (anti-aliased) lines
Screen('BlendFunction', window, 'GL_SRC_ALPHA', 'GL_ONE_MINUS_SRC_ALPHA');

% Here we load in an image from file. This one is a image of rabbits that
% is included with PTB
theImageLocation = [cFolder filesep 'welcome.jpg'];
theImage = imread(theImageLocation);
% Make the image into a texture
imageTexture = Screen('MakeTexture', window, theImage);
% Get the size of the image
[s1, s2, s3] = size(theImage);
% Get the aspect ratio of the image. We need this to maintain the aspect
% ratio of the image when we draw it different sizes. Otherwise, if we
% don't match the aspect ratio the image will appear warped / stretched
aspectRatio = s2 / s1;
% We will set the height of each drawn image to a fraction of the screens
% height
heightScalers = linspace(1, 0.2, 10);
imageHeights = screenYpixels .* heightScalers;
imageWidths = imageHeights .* aspectRatio;
% Number of images we will draw
numImages = numel(heightScalers);
% Make the destination rectangles for our image. We will draw the image
% multiple times over getting smaller on each iteration. So we need the big
% dstRects first followed by the progressively smaller ones
i = 2
theRect = [0 0 imageWidths(i) imageHeights(i)];
dstRects= CenterRectOnPointd(theRect, screenXpixels / 2,screenYpixels / 2);
% Draw the image to the screen, unless otherwise specified PTB will draw
% the texture full size in the center of the screen. We first draw the
% image in its correct orientation.
Screen('DrawTexture', window, imageTexture, [], dstRects);
% Flip to the screen
Screen('Flip', window);
% Wait for action
KbStrokeWait;
introduction1(cFolder,window,dstRects);
introduction2(cFolder,window,dstRects);
introduction3(cFolder,window,dstRects);
preparation(window,screenNumber,xCenter,yCenter,escapeKey,comfrimKey2,ifi);
for g=1:2;
subjdata(g).totalon=GetSecs;
if g ==1
trial_s=trial_s1;
else
trial_s=trial_s2;   
end
%waiting
waitting1(cFolder,window,dstRects,10)
%%
for loop_pra=1:length(trial_s)
subjinfo(cFolder,window,dstRects,loop_pra,trial_s);
[subjdata]=investp(subjdata,g,loop_pra,window,screenNumber,baseRect, xCenter, yCenter,aaxx,escapeKey,comfrimKey,leftKey,rightKey,xyxp,xyx,xyx1,xyy,xyx2,ifi,wid);
%waiting1
waitting1(cFolder,window,dstRects,trial_s(loop_pra)+2,jitter1(g,loop_pra))
%prediction
[subjdata]=predictp(subjdata,g,loop_pra,window,screenNumber,pixelsPerPress1,yCenter,escapeKey,comfrimKey,leftKey,rightKey,xyyp,xyxp,ifi,wid);
%waiting
waitting1(cFolder,window,dstRects,1,jitter2(g,loop_pra))
%response
% Sync us and get a time stamp
[subjdata,i1,i2]=responsep(subjdata,g,loop_pra,window,screenNumber,yCenter,escapeKey,xyyp,xyxp,ifi,wid,xprobilty1,xprobilty2,trial_s,i1,i2);
%waiting
waitting1(cFolder,window,dstRects,2,jitter3(g,loop_pra))
end
subjdata(g).endonset=GetSecs;
if g ==1
preparation2(window,screenNumber,xCenter,yCenter,escapeKey,comfrimKey2,ifi);
else
end
end
%%
%sum
totalin=[];
totalre=[];
for kk=1:g
    for t=1:30
    totalre(t)=[subjdata(kk).response(t).choice(1)];
    end
    totalin(kk)=10*size(totalre,2)-sum([subjdata(kk).invest(:).choice])+sum(totalre);
    for o=1:loop_pra
        if subjdata(kk).invest(o).choice ==0
        else
        cor1(kk,o)=isequal(subjdata(kk).predict(o).choice,subjdata(kk).response(o).choice)
        end
    end
end
    totalpre=sum(sum(cor1));
%      DrawFormattedText(window, [double ('Ͷ������     '),num2str(totalin),' \n\n',double(' Ԥ������     '),num2str(totalpre)],...
%              'center', 'center', black);  
% Screen('Flip', window);1
        exitDemo = false;
        vbl = Screen('Flip', window);
       while exitDemo == false
            Screen('DrawText', window, double(['Ͷ������  ',num2str(sum(totalin))]),xCenter-150, yCenter-30, [0 0 0]);
            Screen('DrawText', window, double(['Ԥ������  ',num2str(totalpre)]), xCenter-150, yCenter+30, [0 0 0]);
%             Screen('DrawText', window, num2str(totalin), xCenter+10, yCenter+60, black);
%             Screen('DrawText', window, num2str(totalpre), xCenter+10, yCenter+30, black);
            % Flip to the screen
            vbl  = Screen('Flip', window, vbl + (1 - 0.5) * ifi);
       [keyIsDown,secs, keyCode] = KbCheck;
         if keyCode(escapeKey)|keyCode(leftKey)|keyCode(rightKey)|keyCode(comfrimKey)
                exitDemo = true;
         end
         end
  
%%1
sca
close all;
save ([subjdata(1).subinfo{1},'_',subjdata(1).subinfo{2},'_practise.mat']);