function introduction2(cFolder,window,dstRects)

% Here we load in an image from file. This one is a image of rabbits that
% is included with PTB
theImageLocation = [cFolder filesep 'introduction2.jpg'];
theImage = imread(theImageLocation);

% Make the image into a texture
imageTexture = Screen('MakeTexture', window, theImage);

% Draw the image to the screen, unless otherwise specified PTB will draw
% the texture full size in the center of the screen. We first draw the
% image in its correct orientation.
Screen('DrawTexture', window, imageTexture, [],dstRects);

% Flip to the screen
Screen('Flip', window);
% Wait for action
KbStrokeWait;