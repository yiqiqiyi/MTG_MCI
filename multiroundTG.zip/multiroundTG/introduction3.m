function introduction3(cFolder,window,dstRects)
theImageLocation = [cFolder filesep 'introduction3.jpg'];
theImage = imread(theImageLocation);

% Make the image into a texture
imageTexture = Screen('MakeTexture', window, theImage);

% Draw the image to the screen, unless otherwise specified PTB will draw
% the texture full size in the center of the screen. We first draw the
% image in its correct orientation.
Screen('DrawTexture', window, imageTexture, [], dstRects);

% Flip to the screen
Screen('Flip', window);

% Wait for action
KbStrokeWait;