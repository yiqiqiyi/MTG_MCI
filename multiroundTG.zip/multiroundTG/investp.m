function [subjdata]=investp(subjdata,g,loop_pra,window,screenNumber,baseRect, xCenter, yCenter,aaxx,escapeKey,comfrimKey,leftKey,rightKey,xyxp,xyx,xyx1,xyy,xyx2,ifi,wid)
%invest
        % Sync us and get a time stamp
        vbl = Screen('Flip', window);
        waitframes = 1;
        
        % Maximum priority level
        topPriorityLevel = MaxPriority(window);
        Priority(topPriorityLevel);      
        % This is the cue which determines whether we exit the demo
        exitDemo = false;
        RT=0.2
        % Loop the animation until the escape key is pressed
        comfirms=0;
        % Set the color of the rect to yellow
        rectColor = [1 1 0];
        % Define black and white
        black = BlackIndex(screenNumber);
        squareX = xCenter;
        squareY = yCenter;
        pixelsPerPress = 1.5*aaxx;
        tEdur = GetSecs;
        tSdur = GetSecs;
        tStart = GetSecs;
        while exitDemo == false
                    % Set the text size
        Screen('TextSize', window, aaxx);
            % Check the keyboard to see if a button has been pressed
            [keyIsDown,secs, keyCode] = KbCheck;
            
            % Depending on the button press, either move ths position of the square
            % or exit the demo
            
            if keyCode(escapeKey)
                sca
                close all;
                error('esc')
            elseif tEdur-tSdur>=4
                exitDemo = true;
            elseif keyCode(comfrimKey)
                rectColor=[1 0 0];
                comfirms=1;
            elseif keyCode(leftKey)& RT>=0.2&comfirms==0
                squareX = squareX - pixelsPerPress;
                tStart = GetSecs;
            elseif keyCode(rightKey)& RT>=0.2&comfirms==0
                squareX = squareX + pixelsPerPress;
                tStart = GetSecs;
            end
            
            % We set bounds to make sure our square doesn't go completely off of
            % the screen
            if squareX < mean(xyx1(5,:))
                squareX = mean(xyx1(5,:));
            elseif squareX > mean(xyx2(5,:))
                squareX = mean(xyx2(5,:));
            end           
           
            % Center the rectangle on the centre of the screen
            centeredRect = CenterRectOnPointd(baseRect, squareX, squareY);
            
            
            % Draw the rect to the screen
            Screen('FillRect', window, [1 1 1], [xyx(1)         xyy(1)        xyx(2)         xyy(2)]);
            Screen('FillRect', window, [1 1 1], [xyx1(1,1)         xyy(1)        xyx1(1,2)         xyy(2)]);
            Screen('FillRect', window, [1 1 1], [xyx1(2,1)         xyy(1)        xyx1(2,2)         xyy(2)]);
            Screen('FillRect', window, [1 1 1], [xyx1(3,1)         xyy(1)        xyx1(3,2)         xyy(2)]);
            Screen('FillRect', window, [1 1 1], [xyx1(4,1)         xyy(1)        xyx1(4,2)         xyy(2)]);
            Screen('FillRect', window, [1 1 1], [xyx1(5,1)         xyy(1)        xyx1(5,2)         xyy(2)]);
            Screen('FillRect', window, [1 1 1], [xyx2(1,1)         xyy(1)        xyx2(1,2)         xyy(2)]);
            Screen('FillRect', window, [1 1 1], [xyx2(2,1)         xyy(1)        xyx2(2,2)         xyy(2)]);
            Screen('FillRect', window, [1 1 1], [xyx2(3,1)         xyy(1)        xyx2(3,2)         xyy(2)]);
            Screen('FillRect', window, [1 1 1], [xyx2(4,1)         xyy(1)        xyx2(4,2)         xyy(2)]);
            Screen('FillRect', window, [1 1 1], [xyx2(5,1)         xyy(1)        xyx2(5,2)         xyy(2)]);
            Screen('FillRect', window, rectColor, centeredRect);
            DrawFormattedText(window, '0', xyx1(5,1)+25, xyy(2)-15, [0 0 0]);
            DrawFormattedText(window, '1', xyx1(4,1)+25, xyy(2)-15, [0 0 0]);
            DrawFormattedText(window, '2', xyx1(3,1)+25, xyy(2)-15, [0 0 0]);
            DrawFormattedText(window, '3', xyx1(2,1)+25, xyy(2)-15, [0 0 0]);
            DrawFormattedText(window, '4', xyx1(1,1)+25, xyy(2)-15, [0 0 0]);
            DrawFormattedText(window, '5', xyx(1)+25, xyy(2)-15, [0 0 0]);
            DrawFormattedText(window, '10', xyx2(5,1)-10, xyy(2)-15, [0 0 0]);
            DrawFormattedText(window, '9', xyx2(4,1)+25, xyy(2)-15, [0 0 0]);
            DrawFormattedText(window, '8', xyx2(3,1)+25, xyy(2)-15, [0 0 0]);
            DrawFormattedText(window, '7', xyx2(2,1)+25, xyy(2)-15, [0 0 0]);
            DrawFormattedText(window, '6', xyx2(1,1)+25, xyy(2)-15, [0 0 0]);
        % Set the text size
            Screen('TextSize', window, 60);
            Screen('DrawText', window, double('��ѡ�����Է��Ľ��'), xyxp(1)-0.3*wid, yCenter/3, black);

            % Flip to the screen
            vbl  = Screen('Flip', window, vbl + (waitframes - 0.5) * ifi);
            
            tEdur = GetSecs;
            tEnd = GetSecs;
            RT=tEnd-tStart;
        end
        subjdata(g).invest(loop_pra).choice=(centeredRect(1)-xyx1(5,1))/(1.5*aaxx);
        subjdata(g).invest(loop_pra).onset=tSdur;
        subjdata(g).invest(loop_pra).confirm=comfirms;
