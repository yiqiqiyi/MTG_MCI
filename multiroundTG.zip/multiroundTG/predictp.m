function [subjdata]=predictp(subjdata,g,loop_pra,window,screenNumber,pixelsPerPress1,yCenter,escapeKey,comfrimKey,leftKey,rightKey,xyyp,xyxp,ifi,wid)
       vbl = Screen('Flip', window);
        waitframes = 1;
        rectColor=[0 0 0]
        % Maximum priority level
        topPriorityLevel = MaxPriority(window);
        Priority(topPriorityLevel);
        % Set the text size
        Screen('TextSize', window, 60);
        black = BlackIndex(screenNumber);
        % This is the cue which determines whether we exit the demo
        exitDemo = false;
        RT=0.2;
        % Loop the animation until the escape key is pressed
        comfirms=0;
        investment=subjdata(g).invest(loop_pra).choice;
        squareX1=round(investment*3/2);
        dist=xyyp(2)-xyyp(1);
        squareperX=squareX1/(investment*3);
        
        tEdur = GetSecs;
        tSdur = GetSecs;
        tStart = GetSecs;
        while exitDemo == false
            
            % Check the keyboard to see if a button has been pressed
            [keyIsDown,secs, keyCode] = KbCheck;
            
            % Depending on the button press, either move ths position of the square
            % or exit the demo
            
            if tEdur-tSdur>=4
                exitDemo = true;
            elseif keyCode(comfrimKey)
                rectColor=[1 0 0];
                comfirms=1;
            elseif keyCode(leftKey)& RT>=0.2&comfirms==0
                squareX1 = squareX1 - pixelsPerPress1;
                squareperX=squareX1/(investment*3);
                tStart = GetSecs;
            elseif keyCode(rightKey)& RT>=0.2&comfirms==0
                squareX1 = squareX1 + pixelsPerPress1;
                squareperX=squareX1/(investment*3);
                tStart = GetSecs;
            elseif keyCode(escapeKey)
                sca
                close all;
                error('esc')
            end
            
            % We set bounds to make sure our square doesn't go completely off of
            % the screen
            if squareX1 < 0
                squareX1 = 0;
                squareperX=0
            elseif squareX1 > investment*3
                squareX1 = investment*3;
                squareperX=1;
            end
            
            
            % Center the rectangle on the centre of the screen
            %         centeredRect = CenterRectOnPointd(baseRect, squareX, squareY);
            % Draw the rect to the screen
            Screen('FillRect', window, [255 66 93]/256, [xyxp(1)         xyyp(1)+squareperX*dist        xyxp(1)+wid         xyyp(2)]);
            Screen('FillRect', window, [147 224 255]/256, [xyxp(2)-wid         xyyp(1)+(1-squareperX)*dist        xyxp(2)         xyyp(2)]);
            
            %draw outline of the screen
            Screen('FramePoly', window, rectColor, [[xyxp(1),xyxp(1)+wid,xyxp(1)+wid,xyxp(1)];...
                [xyyp(1),xyyp(1),xyyp(2),xyyp(2)]]', 5);
            Screen('FramePoly', window, rectColor, [[xyxp(2)-wid,xyxp(2),xyxp(2),xyxp(2)-wid];...
                [xyyp(1),xyyp(1),xyyp(2),xyyp(2)]]', 5);
            %         Screen('FillRect', window, rectColor, centeredRect);
            DrawFormattedText(window, num2str(3*investment-squareX1), xyxp(1)+0.3*wid, xyyp(1)-15, [0 0 0]);
            DrawFormattedText(window, num2str(squareX1), xyxp(2)-0.7*wid, xyyp(1)-15, [0 0 0]);
            Screen('DrawText', window, double('����'),xyxp(1)+10, xyyp(2)+60, [0 0 0]);
            Screen('DrawText', window, double('����'), xyxp(2)-wid+15, xyyp(2)+60, [0 0 0]);
            Screen('DrawText', window, double('Ԥ��Է�ѡ��'), xyxp(1)+0.3*wid, yCenter/3, black);
            
            
            % Flip to the screen
            vbl  = Screen('Flip', window, vbl + (waitframes - 0.5) * ifi);
            
            tEdur = GetSecs;
            tEnd = GetSecs;
            RT=tEnd-tStart;
        end
        subjdata(g).predict(loop_pra).choice=[3*investment-squareX1,squareX1];
        subjdata(g).predict(loop_pra).onset=tSdur;
        subjdata(g).predict(loop_pra).confirm=comfirms;

        