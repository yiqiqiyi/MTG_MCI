function preparation(window,screenNumber,xCenter,yCenter,escapeKey,comfrimKey2,ifi)

% Sync us and get a time stamp
vbl = Screen('Flip', window);
waitframes = 1;
% Maximum priority level
topPriorityLevel = MaxPriority(window);
Priority(topPriorityLevel);
% Set the text size
Screen('TextSize', window, 60);
black = BlackIndex(screenNumber);
exitDemo = false
%plot
while exitDemo == false
        % Check the keyboard to see if a button has been pressed
    [keyIsDown,secs, keyCode] = KbCheck;
    
    % Depending on the button press, either move ths position of the square
    % or exit the demo
    
    if  keyCode(comfrimKey2)
        comfirms=1;
        exitDemo = true
    elseif keyCode(escapeKey)
        sca
        close all;
        error('esc')
    end
    Screen('DrawText', window, double('����Ϣһ�ᣬ�Ժ���Ϸ����'), xCenter*0.6, yCenter, black);
    
    
    % Flip to the screen
    vbl  = Screen('Flip', window, vbl + (waitframes - 0.5) * ifi);
end