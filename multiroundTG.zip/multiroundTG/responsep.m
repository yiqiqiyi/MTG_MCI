function [subjdata,i1,i2]=responsep(subjdata,g,loop_pra,window,screenNumber,yCenter,escapeKey,xyyp,xyxp,ifi,wid,xprobilty1,xprobilty2,trial_s,i1,i2)

        %response
        % Sync us and get a time stamp
        vbl = Screen('Flip', window);
        waitframes = 1;
        trial1=find(trial_s==1);
        trial2=find(trial_s==2);
        black = BlackIndex(screenNumber);
        investment=subjdata(g).invest(loop_pra).choice;
        % Maximum priority level
        topPriorityLevel = MaxPriority(window);
        Priority(topPriorityLevel);
        % Set the text size
        Screen('TextSize', window, 60);
        
        % This is the cue which determines whether we exit the demo
        exitDemo = false;
        waiting=2;
        
        if trial_s(loop_pra)==1
            aa1=rand(1);
            if aa1<=xprobilty1(i1,1)/100
                respo=1;
%                 respo=rand(1)*3;
            elseif aa1>xprobilty1(i1,1)/100 & aa1<=sum(xprobilty1(i1,1:2))/100
                respo=1.5;
%                 respo=rand(1)*3;
            elseif aa1>sum(xprobilty1(i1,1:2))/100
                respo=2;
%                 respo=rand(1)*3;
            end
        else
            aa2=rand(1);
            if aa2<=xprobilty2(i2,3)/100
                respo=0.5;
%                 respo=rand(1)*3;
            elseif aa2>xprobilty2(i2,3)/100 & aa2<=sum(xprobilty2(i2,2:3))/100
                respo=0.75;
%                 respo=rand(1)*3;
            elseif aa2>sum(xprobilty2(i2,2:3))/100
                respo=1;
%                 respo=rand(1)*3;
            end
        end
        
        squareX2=round(respo*investment);
        dist=xyyp(2)-xyyp(1);
        squareperX=squareX2/(investment*3);
        tEdur = GetSecs;
        tSdur = GetSecs;
        while exitDemo == false
            
            % Check the keyboard to see if a button has been pressed
            [keyIsDown,secs, keyCode] = KbCheck;
            
            % Depending on the button press, either move ths position of the square
            % or exit the demo
            
            if keyCode(escapeKey)|tEdur-tSdur>=waiting
                exitDemo = true;
            end
            
            
            % Center the rectangle on the centre of the screen
            %         centeredRect = CenterRectOnPointd(baseRect, squareX2, squareY);
            % Draw the rect to the screen
            Screen('FillRect', window, [255 66 93]/256, [xyxp(1)         xyyp(1)+(1-squareperX)*dist        xyxp(1)+wid         xyyp(2)]);
            Screen('FillRect', window, [147 224 255]/256, [xyxp(2)-wid         xyyp(1)+squareperX*dist        xyxp(2)         xyyp(2)]);
            
            %draw outline of the screen
            Screen('FramePoly', window, [0 0 0], [[xyxp(1),xyxp(1)+wid,xyxp(1)+wid,xyxp(1)];...
                [xyyp(1),xyyp(1),xyyp(2),xyyp(2)]]', 5);
            Screen('FramePoly', window, [0 0 0], [[xyxp(2)-wid,xyxp(2),xyxp(2),xyxp(2)-wid];...
                [xyyp(1),xyyp(1),xyyp(2),xyyp(2)]]', 5);
            %         Screen('FillRect', window, rectColor, centeredRect);
            DrawFormattedText(window, num2str(squareX2), xyxp(1)+0.3*wid, xyyp(1)-15, [0 0 0]);
            DrawFormattedText(window, num2str(3*investment-squareX2), xyxp(2)-0.7*wid, xyyp(1)-15, [0 0 0]);
            Screen('DrawText', window, double('����'),xyxp(1)+10, xyyp(2)+60, [0 0 0]);
            Screen('DrawText', window, double('����'), xyxp(2)-wid+15, xyyp(2)+60, [0 0 0]);
            Screen('DrawText', window, double('�Է����ѡ��'), xyxp(1)+0.3*wid, yCenter/3, black);
            
            
            % Flip to the screen
            vbl  = Screen('Flip', window, vbl + (waitframes - 0.5) * ifi);
            
            tEdur = GetSecs;
        end
        subjdata(g).response(loop_pra).choice=[squareX2,3*investment-squareX2];
        subjdata(g).response(loop_pra).onset=tSdur;
        if ismember (loop_pra,trial1(2:end))
            x=find(trial1==loop_pra)
            if subjdata(g).invest(loop_pra).choice>subjdata(g).invest(trial1(x-1)).choice
                i1=i1+1;
                if i1>13
                    i1=13
                end
            end
        elseif ismember (loop_pra,trial2(2:end))
            x=find(trial2==loop_pra)
            if subjdata(g).invest(loop_pra).choice<subjdata(g).invest(trial2(x-1)).choice
                i2=i2+1;
                if i2>13
                    i2=13
                end
            end
        end
        subjdata(g).response(loop_pra).level=[i1,i2];
        subjdata(g).response(loop_pra).person=trial_s(loop_pra);  