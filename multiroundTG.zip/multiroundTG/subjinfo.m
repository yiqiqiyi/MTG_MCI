function subjinfo(cFolder,window,dstRects,loop_pra,trial_s)

%%
%name
% Make the image into a texture
if trial_s(loop_pra)==1
    theImageLocation = [cFolder filesep 'sub1.jpg'];
    theImage = imread(theImageLocation);
    imageTexture = Screen('MakeTexture', window, theImage);
else
    theImageLocation2 = [cFolder filesep 'sub2.jpg'];
    theImage2 = imread(theImageLocation2);
    imageTexture = Screen('MakeTexture', window, theImage2); 
end
Screen('DrawTexture', window, imageTexture, [], dstRects);
% Flip to the screen
Screen('Flip', window);
% Wait for one seconds
WaitSecs(1.5);