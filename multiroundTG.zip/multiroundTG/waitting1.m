function waitting1(cFolder,window,dstRects,part,time)
if nargin<5
    time=3+2*rand(1);
end

%present waitting
if part==1
    %load waitting
    theImageLocation1 = [cFolder filesep 'waitting.jpg'];
    theImage1 = imread(theImageLocation1);
    % Make the image into a texture
    imageTexture1 = Screen('MakeTexture', window, theImage1);
    Screen('DrawTexture', window, imageTexture1, [], dstRects);
elseif part==2
    %load waitting
    theImageLocation2 = [cFolder filesep 'waitting1.jpg'];
    theImage2 = imread(theImageLocation2);
    % Make the image into a texture
    imageTexture2 = Screen('MakeTexture', window, theImage2);
    Screen('DrawTexture', window, imageTexture2, [], dstRects);
elseif part==3
    %load waitting
    theImageLocation3 = [cFolder filesep 'waittingsub1.jpg'];
    theImage3 = imread(theImageLocation3);
    % Make the image into a texture
    imageTexture3 = Screen('MakeTexture', window, theImage3);
    Screen('DrawTexture', window, imageTexture3, [], dstRects);
elseif part==4
    %load waitting
    theImageLocation4 = [cFolder filesep 'waittingsub2.jpg'];
    theImage4 = imread(theImageLocation4);
    % Make the image into a texture
    imageTexture4 = Screen('MakeTexture', window, theImage4);
    Screen('DrawTexture', window, imageTexture4, [], dstRects);
end
% Flip to the screen
Screen('Flip', window);
% Wait for one seconds
WaitSecs(time);